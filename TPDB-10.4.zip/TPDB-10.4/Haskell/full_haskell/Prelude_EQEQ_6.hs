{-# htermination (==) :: Bool -> Bool -> Bool #-}
