{-# htermination appendFile :: FilePath -> String -> IO () #-}
