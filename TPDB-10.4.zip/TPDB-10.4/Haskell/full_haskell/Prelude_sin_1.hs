{-# htermination sin :: Float -> Float #-}
