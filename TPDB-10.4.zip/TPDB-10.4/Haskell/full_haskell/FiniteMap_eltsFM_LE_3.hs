{-# htermination eltsFM_LE :: FiniteMap Char b -> Char -> [b] #-}
import FiniteMap
