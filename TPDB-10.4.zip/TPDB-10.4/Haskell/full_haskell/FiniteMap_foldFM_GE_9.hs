{-# htermination foldFM_GE :: Ord a => ((Maybe a) -> b -> c -> c) -> c -> (Maybe a) -> FiniteMap (Maybe a) b -> c #-}
import FiniteMap
