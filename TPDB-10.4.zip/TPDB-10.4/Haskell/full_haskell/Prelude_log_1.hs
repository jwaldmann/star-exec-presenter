{-# htermination log :: Float -> Float #-}
