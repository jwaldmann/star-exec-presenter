{-# htermination isLatin1 :: Char -> Bool #-}
