{-# htermination showsPrec :: Int -> (Ratio Int) -> String -> String #-}
