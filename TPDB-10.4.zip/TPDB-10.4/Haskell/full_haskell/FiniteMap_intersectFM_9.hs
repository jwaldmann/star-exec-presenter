{-# htermination intersectFM :: Ord a => FiniteMap (Maybe a) b -> FiniteMap (Maybe a) b -> FiniteMap (Maybe a) b #-}
import FiniteMap
