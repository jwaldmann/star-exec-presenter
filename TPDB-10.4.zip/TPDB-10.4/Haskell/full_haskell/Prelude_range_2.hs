{-# htermination range :: ((),()) -> [()] #-}
