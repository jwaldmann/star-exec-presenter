{-# htermination readParen :: Bool -> (String -> [(Int,String)]) -> (String -> [(Int,String)]) #-}
