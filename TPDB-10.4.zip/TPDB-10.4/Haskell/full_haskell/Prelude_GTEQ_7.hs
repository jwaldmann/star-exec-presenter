{-# htermination (>=) :: (Ratio Int) -> (Ratio Int) -> Bool #-}
