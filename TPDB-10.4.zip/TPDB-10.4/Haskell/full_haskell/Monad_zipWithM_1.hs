{-# htermination zipWithM :: Monad m => (a -> b -> m c) -> [a] -> [b] -> m [c] #-}
import Monad
