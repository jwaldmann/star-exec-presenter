{-# htermination minusFM :: FiniteMap Int b1 -> FiniteMap Int b2 -> FiniteMap Int b1 #-}
import FiniteMap
