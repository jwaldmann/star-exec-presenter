{-# htermination max :: () -> () -> () #-}
