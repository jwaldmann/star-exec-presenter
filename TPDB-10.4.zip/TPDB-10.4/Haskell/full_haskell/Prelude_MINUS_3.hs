{-# htermination (-) :: Float -> Float -> Float #-}
