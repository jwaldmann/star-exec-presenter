{-# htermination minimum :: Ord a => [a] -> a #-}
