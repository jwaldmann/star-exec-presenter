{-# htermination fmToList_LE :: FiniteMap () b -> () ->  [((),b)] #-}
import FiniteMap
