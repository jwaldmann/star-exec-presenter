{-# htermination elemIndices :: Char -> [Char] -> [Int] #-}
import List
