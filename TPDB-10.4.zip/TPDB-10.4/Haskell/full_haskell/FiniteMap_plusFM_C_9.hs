{-# htermination plusFM_C :: Ord a => (b -> b -> b) -> FiniteMap (Maybe a) b -> FiniteMap (Maybe a) b -> FiniteMap (Maybe a) b #-}
import FiniteMap
