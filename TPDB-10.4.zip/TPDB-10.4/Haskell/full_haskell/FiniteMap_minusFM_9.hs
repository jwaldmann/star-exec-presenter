{-# htermination minusFM :: Ord a => FiniteMap (Maybe a) b1 -> FiniteMap (Maybe a) b2 -> FiniteMap (Maybe a) b1 #-}
import FiniteMap
