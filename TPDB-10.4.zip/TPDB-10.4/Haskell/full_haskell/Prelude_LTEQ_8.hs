{-# htermination (<=) :: Bool -> Bool -> Bool #-}
