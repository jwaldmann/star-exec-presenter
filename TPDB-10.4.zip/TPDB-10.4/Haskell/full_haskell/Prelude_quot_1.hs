{-# htermination quot :: Int -> Int -> Int #-}
