{-# htermination sort :: (Ord a, Ord k) => [(a,k)] -> [(a,k)] #-}
import List
