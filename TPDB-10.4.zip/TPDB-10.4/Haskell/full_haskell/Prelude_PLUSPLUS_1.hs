{-# htermination (++) :: [a] -> [a] -> [a] #-}
