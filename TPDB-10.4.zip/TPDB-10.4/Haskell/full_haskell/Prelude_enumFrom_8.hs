{-# htermination enumFrom :: Ordering -> [Ordering] #-}
