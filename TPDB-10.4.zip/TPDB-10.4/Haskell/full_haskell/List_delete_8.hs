{-# htermination delete :: Float -> [Float] -> [Float] #-}
import List
