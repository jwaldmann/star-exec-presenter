{-# htermination toEnum :: Int -> Int #-}
