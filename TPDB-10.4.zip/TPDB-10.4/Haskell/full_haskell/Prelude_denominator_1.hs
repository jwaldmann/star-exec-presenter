{-# htermination denominator :: Ratio Int -> Int #-}
