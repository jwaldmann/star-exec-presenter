{-# htermination enumFrom :: () -> [()] #-}
