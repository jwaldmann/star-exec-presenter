{-# htermination isPrefixOf :: [Bool] -> [Bool] -> Bool #-}
import List
