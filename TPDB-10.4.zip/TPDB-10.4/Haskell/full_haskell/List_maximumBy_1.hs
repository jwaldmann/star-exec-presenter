{-# htermination maximumBy :: (a -> a -> Ordering) -> [a] -> a #-}
import List
