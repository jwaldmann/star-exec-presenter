{-# htermination min :: (Ord a, Ord k) => (a,k) -> (a,k) -> (a,k) #-}
