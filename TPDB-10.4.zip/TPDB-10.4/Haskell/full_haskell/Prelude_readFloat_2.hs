{-# htermination readFloat :: (String -> [(Float,String)]) #-}
