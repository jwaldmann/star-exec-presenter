{-# htermination reads :: String -> [(Float,String)] #-}
