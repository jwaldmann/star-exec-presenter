{-# htermination fmToList_GE :: FiniteMap Bool b -> Bool ->  [(Bool,b)] #-}
import FiniteMap
