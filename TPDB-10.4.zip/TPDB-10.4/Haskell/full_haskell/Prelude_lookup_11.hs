{-# htermination lookup :: (Eq a, Eq k) => (Either a k) -> [((Either a k),b)] -> Maybe b #-}
