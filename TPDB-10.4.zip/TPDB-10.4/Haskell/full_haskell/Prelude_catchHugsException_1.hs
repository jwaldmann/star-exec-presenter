{-# htermination catchHugsException :: IO a -> (HugsException -> IO a) -> IO a #-}
