{-# htermination subtract :: (Ratio Int) -> (Ratio Int) -> (Ratio Int) #-}
