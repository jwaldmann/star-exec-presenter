{-# htermination foldFM_GE :: (Char -> b -> c -> c) -> c -> Char -> FiniteMap Char b -> c #-}
import FiniteMap
