{-# htermination eltsFM_GE :: FiniteMap Float b -> Float -> [b] #-}
import FiniteMap
