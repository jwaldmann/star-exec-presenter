{-# htermination max :: Ord a => a -> a -> a #-}
