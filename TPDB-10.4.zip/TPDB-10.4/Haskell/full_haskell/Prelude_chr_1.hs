{-# htermination chr :: Int -> Char #-}
