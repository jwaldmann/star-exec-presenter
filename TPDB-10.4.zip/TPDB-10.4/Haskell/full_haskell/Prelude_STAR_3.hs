{-# htermination (*) :: Float -> Float -> Float #-}
