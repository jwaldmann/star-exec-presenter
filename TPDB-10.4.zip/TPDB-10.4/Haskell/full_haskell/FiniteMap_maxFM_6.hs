{-# htermination maxFM :: FiniteMap Float b -> Maybe Float #-}
import FiniteMap
