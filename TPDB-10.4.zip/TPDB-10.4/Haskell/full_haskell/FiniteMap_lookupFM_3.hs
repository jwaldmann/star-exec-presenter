{-# htermination lookupFM :: FiniteMap Char b -> Char -> Maybe b #-}
import FiniteMap
