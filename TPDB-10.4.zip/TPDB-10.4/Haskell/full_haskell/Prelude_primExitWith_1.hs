{-# htermination primExitWith :: Int -> IO a #-}
