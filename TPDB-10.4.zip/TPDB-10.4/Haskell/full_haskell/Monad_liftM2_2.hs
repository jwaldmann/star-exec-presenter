{-# htermination liftM2 :: (a -> b -> c) -> ([] a -> [] b -> [] c) #-}
import Monad
