{-# htermination isPrefixOf :: Eq a => [[a]] -> [[a]] -> Bool #-}
import List
