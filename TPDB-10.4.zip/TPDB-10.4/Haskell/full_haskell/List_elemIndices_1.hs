{-# htermination elemIndices :: () -> [()] -> [Int] #-}
import List
