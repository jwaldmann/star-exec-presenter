{-# htermination return :: a -> [] a #-}
