{-# htermination queueToList :: Queue a -> [a] #-}
import Queue
