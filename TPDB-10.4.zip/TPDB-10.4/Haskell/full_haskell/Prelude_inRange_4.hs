{-# htermination inRange :: (Int,Int) -> Int -> Bool #-}
