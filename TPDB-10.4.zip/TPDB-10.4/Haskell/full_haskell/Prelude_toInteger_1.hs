{-# htermination toInteger :: Int -> Integer #-}
