{-# htermination delFromFM :: FiniteMap Char b -> Char   -> FiniteMap Char b #-}
import FiniteMap
