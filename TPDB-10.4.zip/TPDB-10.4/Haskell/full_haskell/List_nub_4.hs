{-# htermination nub :: Eq a => [[a]] -> [[a]] #-}
import List
