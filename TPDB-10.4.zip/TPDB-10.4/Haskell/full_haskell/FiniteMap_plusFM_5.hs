{-# htermination plusFM :: FiniteMap Int b -> FiniteMap Int b -> FiniteMap Int b #-}
import FiniteMap
