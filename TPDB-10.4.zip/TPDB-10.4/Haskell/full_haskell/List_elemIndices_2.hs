{-# htermination elemIndices :: Eq a => a -> [a] -> [Int] #-}
import List
