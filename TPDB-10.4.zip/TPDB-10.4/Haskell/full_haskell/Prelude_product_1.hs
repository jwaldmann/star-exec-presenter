{-# htermination product :: Num a => [a] -> a #-}
