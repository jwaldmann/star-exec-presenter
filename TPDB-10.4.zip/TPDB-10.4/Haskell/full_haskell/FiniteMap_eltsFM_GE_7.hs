{-# htermination eltsFM_GE :: FiniteMap (Ratio Int) b -> (Ratio Int) -> [b] #-}
import FiniteMap
