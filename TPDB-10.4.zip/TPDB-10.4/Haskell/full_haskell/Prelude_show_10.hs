{-# htermination show :: (Show a) => (Maybe a) -> String #-}
