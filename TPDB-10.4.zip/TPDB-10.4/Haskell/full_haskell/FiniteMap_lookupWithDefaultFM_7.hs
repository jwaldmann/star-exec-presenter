{-# htermination lookupWithDefaultFM :: FiniteMap (Ratio Int) b -> b -> (Ratio Int) -> b #-}
import FiniteMap
