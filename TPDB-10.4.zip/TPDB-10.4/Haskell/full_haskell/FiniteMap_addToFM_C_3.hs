{-# htermination addToFM_C :: (b -> b -> b) -> FiniteMap Char b -> Char -> b -> FiniteMap Char b #-}
import FiniteMap
