{-# htermination replicate :: Int -> a -> [a] #-}
