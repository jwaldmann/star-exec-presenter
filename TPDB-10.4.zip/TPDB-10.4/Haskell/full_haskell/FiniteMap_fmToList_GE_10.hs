{-# htermination fmToList_GE :: (Ord a, Ord k) => FiniteMap (Either a k) b -> (Either a k) ->  [((Either a k),b)] #-}
import FiniteMap
