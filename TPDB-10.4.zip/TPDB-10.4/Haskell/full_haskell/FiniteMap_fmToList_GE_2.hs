{-# htermination fmToList_GE :: FiniteMap () b -> () ->  [((),b)] #-}
import FiniteMap
