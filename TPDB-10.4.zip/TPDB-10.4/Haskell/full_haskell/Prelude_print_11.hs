{-# htermination print :: (Show a, Show k) => (Either a k) -> IO () #-}
