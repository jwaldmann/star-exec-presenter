{-# htermination readsPrec :: Int -> String -> [((),String)] #-}
