{-# htermination readIO :: String -> IO () #-}
