{-# htermination minimum :: [Bool] -> Bool #-}
