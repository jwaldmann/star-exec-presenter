{-# htermination fromInt :: Int -> (Ratio Int) #-}
