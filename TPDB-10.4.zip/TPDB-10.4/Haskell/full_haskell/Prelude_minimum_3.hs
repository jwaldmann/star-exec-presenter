{-# htermination minimum :: [Char] -> Char #-}
