{-# htermination seq :: a -> b -> b #-}
