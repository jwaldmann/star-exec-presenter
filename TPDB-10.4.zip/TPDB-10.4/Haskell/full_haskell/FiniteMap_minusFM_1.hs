{-# htermination minusFM :: Ord a => FiniteMap a b1 -> FiniteMap a b2 -> FiniteMap a b1 #-}
import FiniteMap
