{-# htermination showParen :: Bool -> (String -> String) -> String -> String #-}
