{-# htermination putStr :: String -> IO () #-}
