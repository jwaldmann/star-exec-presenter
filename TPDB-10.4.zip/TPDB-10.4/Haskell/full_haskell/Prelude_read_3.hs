{-# htermination read :: String -> Char #-}
