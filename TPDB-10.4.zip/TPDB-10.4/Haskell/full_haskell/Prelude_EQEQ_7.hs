{-# htermination (==) :: Ordering -> Ordering -> Bool #-}
