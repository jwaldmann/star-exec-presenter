{-# htermination maxBound :: Ordering #-}
