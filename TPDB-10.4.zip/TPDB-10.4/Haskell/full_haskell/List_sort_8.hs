{-# htermination sort :: [Bool] -> [Bool] #-}
import List
