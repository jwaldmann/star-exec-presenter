{-# htermination all :: (a -> Bool) -> [a] -> Bool #-}
