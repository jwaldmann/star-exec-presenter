{-# htermination foldM :: (a -> b -> [] a) -> a -> [b] -> [] a  #-}
import Monad
