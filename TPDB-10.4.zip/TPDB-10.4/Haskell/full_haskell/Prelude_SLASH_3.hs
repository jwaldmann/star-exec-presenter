{-# htermination (/) :: (Ratio Int) -> (Ratio Int) -> (Ratio Int) #-}
