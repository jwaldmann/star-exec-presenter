{-# htermination (\\) :: [Ordering] -> [Ordering] -> [Ordering] #-}
import List
