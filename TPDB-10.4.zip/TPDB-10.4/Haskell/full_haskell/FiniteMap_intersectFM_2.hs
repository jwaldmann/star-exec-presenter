{-# htermination intersectFM :: FiniteMap () b -> FiniteMap () b -> FiniteMap () b #-}
import FiniteMap
