{-# htermination elemFM :: Float -> FiniteMap Float b -> Bool #-}
import FiniteMap
