{-# htermination intersectFM :: FiniteMap Float b -> FiniteMap Float b -> FiniteMap Float b #-}
import FiniteMap
