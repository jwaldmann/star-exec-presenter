{-# htermination eltsFM_LE :: (Ord a, Ord k) => FiniteMap (a,k) b -> (a,k) -> [b] #-}
import FiniteMap
