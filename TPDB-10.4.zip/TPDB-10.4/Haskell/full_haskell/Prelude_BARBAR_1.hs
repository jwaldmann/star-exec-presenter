{-# htermination (||) :: Bool -> Bool -> Bool #-}
