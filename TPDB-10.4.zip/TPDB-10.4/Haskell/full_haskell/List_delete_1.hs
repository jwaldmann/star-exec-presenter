{-# htermination delete :: Eq a => a -> [a] -> [a] #-}
import List
