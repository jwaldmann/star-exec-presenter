{-# htermination liftM :: (a -> b) -> (IO a -> IO b) #-}
import Monad
