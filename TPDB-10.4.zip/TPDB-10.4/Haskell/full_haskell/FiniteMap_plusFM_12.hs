{-# htermination plusFM :: (Ord a, Ord k) => FiniteMap (a,k) b -> FiniteMap (a,k) b -> FiniteMap (a,k) b #-}
import FiniteMap
