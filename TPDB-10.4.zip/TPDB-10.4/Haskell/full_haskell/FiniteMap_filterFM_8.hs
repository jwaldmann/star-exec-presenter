{-# htermination filterFM :: (Bool -> b -> Bool) -> FiniteMap Bool b -> FiniteMap Bool b #-}
import FiniteMap
