{-# htermination isSuffixOf :: [Ordering] -> [Ordering] -> Bool #-}
import List
