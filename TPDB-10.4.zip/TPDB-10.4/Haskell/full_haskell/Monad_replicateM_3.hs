{-# htermination replicateM :: Int -> Maybe a -> Maybe [a] #-}
import Monad
