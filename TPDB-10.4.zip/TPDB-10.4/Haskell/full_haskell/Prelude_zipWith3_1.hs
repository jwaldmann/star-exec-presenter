{-# htermination zipWith3 :: (a->b->c->d) -> [a]->[b]->[c]->[d] #-}
