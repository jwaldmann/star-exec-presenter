{-# htermination and :: [Bool] -> Bool #-}
