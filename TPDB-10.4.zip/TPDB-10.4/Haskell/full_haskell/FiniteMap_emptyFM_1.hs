{-# htermination emptyFM :: FiniteMap a b #-}
import FiniteMap
