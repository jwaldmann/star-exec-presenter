{-# htermination toEnum :: Enum a => Int -> a #-}
