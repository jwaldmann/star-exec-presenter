{-# htermination (==) :: (Eq a, Eq k) => (a, k) -> (a, k) -> Bool #-}
