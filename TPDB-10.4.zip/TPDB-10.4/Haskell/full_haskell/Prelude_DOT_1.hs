{-# htermination (.) :: (b -> c) -> (a -> b) -> (a -> c) #-}
