{-# htermination elemFM :: Bool -> FiniteMap Bool b -> Bool #-}
import FiniteMap
