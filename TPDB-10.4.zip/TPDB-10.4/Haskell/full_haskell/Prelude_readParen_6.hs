{-# htermination readParen :: Bool -> (String -> [(Float,String)]) -> (String -> [(Float,String)]) #-}
