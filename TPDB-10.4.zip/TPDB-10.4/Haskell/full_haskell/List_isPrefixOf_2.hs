{-# htermination isPrefixOf :: [()] -> [()] -> Bool #-}
import List
