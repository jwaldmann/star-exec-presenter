{-# htermination listToFM :: [(Char,b)] -> FiniteMap Char b #-}
import FiniteMap
