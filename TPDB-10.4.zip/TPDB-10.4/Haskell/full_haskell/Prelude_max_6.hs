{-# htermination max :: Float -> Float -> Float #-}
