{-# htermination intersectFM_C :: (b1 -> b2 -> b3) -> FiniteMap Int b1 -> FiniteMap Int b2 -> FiniteMap Int b3 #-}
import FiniteMap
