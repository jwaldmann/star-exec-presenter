{-# htermination listToFM :: [(Float,b)] -> FiniteMap Float b #-}
import FiniteMap
