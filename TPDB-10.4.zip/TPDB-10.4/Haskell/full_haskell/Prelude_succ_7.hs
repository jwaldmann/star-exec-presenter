{-# htermination succ :: Bool -> Bool #-}
