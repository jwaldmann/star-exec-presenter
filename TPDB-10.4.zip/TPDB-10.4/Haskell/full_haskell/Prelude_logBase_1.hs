{-# htermination logBase :: Float -> Float -> Float #-}
