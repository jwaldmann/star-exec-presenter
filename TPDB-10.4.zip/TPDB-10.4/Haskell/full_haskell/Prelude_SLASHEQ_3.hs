{-# htermination (/=) :: Char -> Char -> Bool #-}
