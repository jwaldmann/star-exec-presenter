{-# htermination shows :: (Ratio Int) -> String -> String #-}
