{-# htermination liftM5 :: (a -> b -> c -> d -> e -> f) -> (IO a -> IO b -> IO c -> IO d -> IO e -> IO f) #-}
import Monad
