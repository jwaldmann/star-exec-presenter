{-# htermination compare :: Char -> Char -> Ordering #-}
