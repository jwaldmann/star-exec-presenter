{-# htermination readIO :: Read a => String -> IO a #-}
