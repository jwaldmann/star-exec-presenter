{-# htermination min :: Char -> Char -> Char #-}
