{-# htermination readParen :: Bool -> (String -> [(Bool,String)]) -> (String -> [(Bool,String)]) #-}
