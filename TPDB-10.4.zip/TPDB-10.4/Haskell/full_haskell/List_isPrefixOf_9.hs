{-# htermination isPrefixOf :: [(Ratio Int)] -> [(Ratio Int)] -> Bool #-}
import List
