{-# htermination foldl :: (a -> b -> a) -> a -> [b] -> a #-}
