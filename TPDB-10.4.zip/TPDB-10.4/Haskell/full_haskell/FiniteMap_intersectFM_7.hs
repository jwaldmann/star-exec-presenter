{-# htermination intersectFM :: FiniteMap (Ratio Int) b -> FiniteMap (Ratio Int) b -> FiniteMap (Ratio Int) b #-}
import FiniteMap
