{-# htermination minBound :: Bounded a => a #-}
