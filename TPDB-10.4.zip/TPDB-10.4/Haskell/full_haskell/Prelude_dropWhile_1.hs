{-# htermination dropWhile :: (a -> Bool) -> [a] -> [a] #-}
