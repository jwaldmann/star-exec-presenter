{-# htermination eltsFM :: FiniteMap a b -> [b] #-}
import FiniteMap
