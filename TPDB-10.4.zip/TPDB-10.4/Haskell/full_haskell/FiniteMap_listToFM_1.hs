{-# htermination listToFM :: Ord a => [(a,b)] -> FiniteMap a b #-}
import FiniteMap
