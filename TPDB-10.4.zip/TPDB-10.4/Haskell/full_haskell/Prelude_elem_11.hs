{-# htermination elem :: (Eq a, Eq k) => (Either a k) -> [(Either a k)] -> Bool #-}
