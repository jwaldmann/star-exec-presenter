{-# htermination (>=) :: Ord a => [a] -> [a] -> Bool #-}
