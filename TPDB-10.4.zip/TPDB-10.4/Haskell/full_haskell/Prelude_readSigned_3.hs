{-# htermination readSigned :: (String -> [(Float,String)]) -> (String -> [(Float,String)]) #-}
