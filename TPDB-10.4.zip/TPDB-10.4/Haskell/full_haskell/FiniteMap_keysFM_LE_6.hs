{-# htermination keysFM_LE :: FiniteMap Float b -> Float -> [Float] #-}
import FiniteMap
