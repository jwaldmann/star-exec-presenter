{-# htermination lookupFM :: FiniteMap () b -> () -> Maybe b #-}
import FiniteMap
