{-# htermination fmap :: (a -> b) -> ([] a -> [] b) #-}
