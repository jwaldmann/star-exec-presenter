{-# htermination liftM5 :: Monad m => (a -> b -> c -> d -> e -> f) -> (m a -> m b -> m c -> m d -> m e -> m f) #-}
import Monad
