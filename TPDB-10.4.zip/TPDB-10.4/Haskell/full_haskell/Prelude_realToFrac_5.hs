{-# htermination realToFrac :: Real a => a -> Ratio Int #-}
