{-# htermination lookupWithDefaultFM :: Ord a => FiniteMap (Maybe a) b -> b -> (Maybe a) -> b #-}
import FiniteMap
