{-# htermination min :: Ord a => [a] -> [a] -> [a] #-}
