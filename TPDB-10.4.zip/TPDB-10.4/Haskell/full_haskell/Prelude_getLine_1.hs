{-# htermination getLine :: IO String #-}
