{-# htermination succ :: Enum a => a -> a #-}
