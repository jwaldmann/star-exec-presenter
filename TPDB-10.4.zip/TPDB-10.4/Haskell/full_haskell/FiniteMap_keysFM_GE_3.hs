{-# htermination keysFM_GE :: FiniteMap Char b -> Char -> [Char] #-}
import FiniteMap
