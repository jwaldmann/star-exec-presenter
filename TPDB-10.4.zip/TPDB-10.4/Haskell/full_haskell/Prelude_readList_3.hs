{-# htermination readList :: String -> [([Char],String)] #-}
