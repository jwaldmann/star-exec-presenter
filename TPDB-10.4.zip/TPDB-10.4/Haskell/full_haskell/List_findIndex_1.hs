{-# htermination findIndex :: (a -> Bool) -> [a] -> Maybe Int #-}
import List
