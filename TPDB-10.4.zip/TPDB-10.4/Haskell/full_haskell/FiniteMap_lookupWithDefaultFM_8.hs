{-# htermination lookupWithDefaultFM :: FiniteMap Bool b -> b -> Bool -> b #-}
import FiniteMap
