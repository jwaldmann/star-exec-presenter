{-# htermination eltsFM_LE :: FiniteMap Float b -> Float -> [b] #-}
import FiniteMap
