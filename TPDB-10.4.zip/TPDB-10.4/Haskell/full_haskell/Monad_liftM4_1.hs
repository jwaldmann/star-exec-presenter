{-# htermination liftM4 :: Monad m => (a -> b -> c -> d -> e) -> (m a -> m b -> m c -> m d -> m e) #-}
import Monad
