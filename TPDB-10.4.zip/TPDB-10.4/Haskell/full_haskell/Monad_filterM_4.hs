{-# htermination filterM :: (a -> IO Bool) -> [a] -> IO [a] #-}
import Monad
