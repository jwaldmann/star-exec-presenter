{-# htermination toRational :: Real a => a -> Rational #-}
