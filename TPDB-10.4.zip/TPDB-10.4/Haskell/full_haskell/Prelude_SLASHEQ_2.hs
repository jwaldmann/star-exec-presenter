{-# htermination (/=) :: () -> () -> Bool #-}
