{-# htermination (>>) :: Maybe a -> Maybe b -> Maybe b #-}
