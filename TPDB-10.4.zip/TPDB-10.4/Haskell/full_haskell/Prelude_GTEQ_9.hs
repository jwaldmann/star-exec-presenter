{-# htermination (>=) :: Ord a => (Maybe a) -> (Maybe a) -> Bool #-}
