{-# htermination zipWithM_ :: Monad m => (a -> b -> m c) -> [a] -> [b] -> m () #-}
import Monad
