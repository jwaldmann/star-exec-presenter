{-# htermination mapFM :: (a -> b1 -> b2) -> FiniteMap a b1 -> FiniteMap a b2 #-}
import FiniteMap
