{-# htermination unzip3 :: [(a,b,c)] -> ([a],[b],[c]) #-}
