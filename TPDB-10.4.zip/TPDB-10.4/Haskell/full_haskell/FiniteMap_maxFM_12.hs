{-# htermination maxFM :: (Ord a, Ord k) => FiniteMap (a,k) b -> Maybe (a,k) #-}
import FiniteMap
