{-# htermination (/) :: Float -> Float -> Float #-}
