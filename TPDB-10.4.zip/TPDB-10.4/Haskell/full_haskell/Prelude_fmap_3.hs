{-# htermination fmap :: (a -> b) -> (Maybe a -> Maybe b) #-}
