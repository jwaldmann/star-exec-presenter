{-# htermination scanl1 :: (a -> a -> a) -> [a] -> [a] #-}
