{-# htermination elemIndices :: Int -> [Int] -> [Int] #-}
import List
