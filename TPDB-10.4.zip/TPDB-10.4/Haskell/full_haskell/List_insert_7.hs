{-# htermination insert :: (Ratio Int) -> [(Ratio Int)] -> [(Ratio Int)] #-}
import List
