{-# htermination reads :: String -> [((Ratio Int),String)] #-}
