{-# htermination maximum :: [Char] -> Char #-}
