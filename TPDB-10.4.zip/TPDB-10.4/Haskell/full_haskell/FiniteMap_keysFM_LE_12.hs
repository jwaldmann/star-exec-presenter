{-# htermination keysFM_LE :: (Ord a, Ord k) => FiniteMap (a,k) b -> (a,k) -> [(a,k)] #-}
import FiniteMap
