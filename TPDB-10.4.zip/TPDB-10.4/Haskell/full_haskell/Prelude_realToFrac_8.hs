{-# htermination realToFrac :: (Ratio Int) -> Ratio Int #-}
