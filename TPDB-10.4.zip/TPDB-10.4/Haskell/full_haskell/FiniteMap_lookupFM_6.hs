{-# htermination lookupFM :: FiniteMap Float b -> Float -> Maybe b #-}
import FiniteMap
