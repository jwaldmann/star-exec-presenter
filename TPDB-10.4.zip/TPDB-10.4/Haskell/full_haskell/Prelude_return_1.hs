{-# htermination return :: Monad m => a -> m a #-}
