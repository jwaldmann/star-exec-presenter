{-# htermination addToFM :: (Ord a, Ord k) => FiniteMap (Either a k) b -> (Either a k) -> b  -> FiniteMap (Either a k) b #-}
import FiniteMap
