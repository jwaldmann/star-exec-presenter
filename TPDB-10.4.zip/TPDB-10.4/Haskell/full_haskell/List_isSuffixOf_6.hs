{-# htermination isSuffixOf :: [Bool] -> [Bool] -> Bool #-}
import List
