{-# htermination primThrowException :: HugsException -> a #-}
