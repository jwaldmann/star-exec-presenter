{-# htermination succ :: Char -> Char #-}
