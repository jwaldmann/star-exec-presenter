{-# htermination readLitChar :: String -> [(Char, String)] #-}
