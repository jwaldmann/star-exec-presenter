{-# htermination min :: () -> () -> () #-}
