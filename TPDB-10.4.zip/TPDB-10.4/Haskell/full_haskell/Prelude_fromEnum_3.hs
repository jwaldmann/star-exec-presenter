{-# htermination fromEnum :: Char -> Int #-}
