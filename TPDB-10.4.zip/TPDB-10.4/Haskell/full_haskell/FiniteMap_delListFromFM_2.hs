{-# htermination delListFromFM :: FiniteMap () b -> [()] -> FiniteMap () b #-}
import FiniteMap
