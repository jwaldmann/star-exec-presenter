{-# htermination concatMap :: (a -> [b]) -> [a] -> [b] #-}
