{-# htermination maximum :: [Bool] -> Bool #-}
