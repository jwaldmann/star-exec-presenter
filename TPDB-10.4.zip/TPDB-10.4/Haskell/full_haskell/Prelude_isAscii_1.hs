{-# htermination isAscii :: Char -> Bool #-}
