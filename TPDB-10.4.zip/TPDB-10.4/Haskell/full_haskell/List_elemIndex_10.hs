{-# htermination elemIndex :: Eq a => (Maybe a) -> [(Maybe a)] -> Maybe Int #-}
import List
