{-# htermination mapMaybe :: (a -> Maybe b) -> [a] -> [b] #-}
import Maybe
