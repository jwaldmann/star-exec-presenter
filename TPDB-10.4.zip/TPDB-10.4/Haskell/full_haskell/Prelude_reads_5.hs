{-# htermination reads :: String -> [(Int,String)] #-}
