{-# htermination fromIntegral :: Num a => Int -> a #-}
