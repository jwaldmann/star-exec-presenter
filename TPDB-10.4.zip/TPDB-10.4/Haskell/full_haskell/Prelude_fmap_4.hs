{-# htermination fmap :: (a -> b) -> (IO a -> IO b) #-}
