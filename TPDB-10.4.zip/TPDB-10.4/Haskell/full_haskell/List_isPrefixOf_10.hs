{-# htermination isPrefixOf :: Eq a => [(Maybe a)] -> [(Maybe a)] -> Bool #-}
import List
