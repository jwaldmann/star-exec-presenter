{-# htermination div :: Int -> Int -> Int #-}
