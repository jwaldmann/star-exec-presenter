{-# htermination addListToFM :: FiniteMap Bool b -> [(Bool,b)] -> FiniteMap Bool b #-}
import FiniteMap
