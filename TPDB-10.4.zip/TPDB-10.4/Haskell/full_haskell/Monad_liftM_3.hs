{-# htermination liftM :: (a -> b) -> (Maybe a -> Maybe b) #-}
import Monad
