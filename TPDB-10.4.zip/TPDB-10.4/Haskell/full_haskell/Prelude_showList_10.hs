{-# htermination showList :: (Show a) => [(Maybe a)] -> String -> String #-}
