{-# htermination minimum :: [()] -> () #-}
