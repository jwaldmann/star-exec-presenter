{-# htermination eltsFM_LE :: FiniteMap Int b -> Int -> [b] #-}
import FiniteMap
