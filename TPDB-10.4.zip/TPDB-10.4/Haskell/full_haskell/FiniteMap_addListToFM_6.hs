{-# htermination addListToFM :: FiniteMap Float b -> [(Float,b)] -> FiniteMap Float b #-}
import FiniteMap
