{-# htermination plusFM :: FiniteMap Ordering b -> FiniteMap Ordering b -> FiniteMap Ordering b #-}
import FiniteMap
