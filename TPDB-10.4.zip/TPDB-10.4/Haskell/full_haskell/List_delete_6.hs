{-# htermination delete :: Bool -> [Bool] -> [Bool] #-}
import List
