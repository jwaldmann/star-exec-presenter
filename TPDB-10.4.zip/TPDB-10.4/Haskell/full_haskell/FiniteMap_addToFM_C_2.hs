{-# htermination addToFM_C :: (b -> b -> b) -> FiniteMap () b -> () -> b -> FiniteMap () b #-}
import FiniteMap
