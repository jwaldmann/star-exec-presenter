{-# htermination min :: Int -> Int -> Int #-}
