{-# htermination fromIntegral :: Int -> (Ratio Int) #-}
