{-# htermination isHexDigit :: Char -> Bool #-}
