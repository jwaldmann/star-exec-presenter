{-# htermination ap :: Monad m => m (a -> b) -> m a -> m b #-}
import Monad
