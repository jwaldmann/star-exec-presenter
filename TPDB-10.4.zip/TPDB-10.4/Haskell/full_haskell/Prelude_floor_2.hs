{-# htermination floor :: (Ratio Int) -> Int #-}
