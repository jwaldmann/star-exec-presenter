{-# htermination emptyQueue :: Queue a #-}
import Queue
