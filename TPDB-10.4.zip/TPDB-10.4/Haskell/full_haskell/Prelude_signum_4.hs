{-# htermination signum :: (Ratio Int) -> (Ratio Int) #-}
