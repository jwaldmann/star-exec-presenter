{-# htermination elemFM :: () -> FiniteMap () b -> Bool #-}
import FiniteMap
