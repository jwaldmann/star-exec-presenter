{-# htermination eltsFM_GE :: FiniteMap Char b -> Char -> [b] #-}
import FiniteMap
