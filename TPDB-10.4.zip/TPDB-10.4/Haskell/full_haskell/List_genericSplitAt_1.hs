{-# htermination genericSplitAt :: Int -> [b] -> ([b],[b]) #-}
import List
