{-# htermination intersperse :: a -> [a] -> [a] #-}
import List
