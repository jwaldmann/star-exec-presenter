{-# htermination showList :: (Show a, Show k) => [(a,k)] -> String -> String #-}
