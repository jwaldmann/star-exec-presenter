{-# htermination reads :: String -> [((),String)] #-}
