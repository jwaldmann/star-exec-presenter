{-# htermination eltsFM_GE :: Ord a => FiniteMap a b -> a -> [b] #-}
import FiniteMap
