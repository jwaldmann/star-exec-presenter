{-# htermination fromDouble :: Double -> (Ratio Int) #-}
