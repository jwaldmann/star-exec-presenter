{-# htermination liftM4 :: (a -> b -> c -> d -> e) -> (IO a -> IO b -> IO c -> IO d -> IO e) #-}
import Monad
