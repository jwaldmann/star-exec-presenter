{-# htermination lexLitChar :: String -> [(String,String)] #-}
