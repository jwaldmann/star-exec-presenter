{-# htermination when :: Monad m => Bool -> m () -> m () #-}
import Monad
