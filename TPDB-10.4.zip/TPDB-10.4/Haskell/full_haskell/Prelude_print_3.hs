{-# htermination print :: Char -> IO () #-}
