{-# htermination (\\) :: [Float] -> [Float] -> [Float] #-}
import List
