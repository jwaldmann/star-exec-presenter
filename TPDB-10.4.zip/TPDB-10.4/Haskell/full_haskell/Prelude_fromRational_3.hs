{-# htermination fromRational :: Rational -> (Ratio Int) #-}
