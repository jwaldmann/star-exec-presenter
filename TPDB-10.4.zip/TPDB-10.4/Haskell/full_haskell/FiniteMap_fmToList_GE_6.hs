{-# htermination fmToList_GE :: FiniteMap Float b -> Float ->  [(Float,b)] #-}
import FiniteMap
