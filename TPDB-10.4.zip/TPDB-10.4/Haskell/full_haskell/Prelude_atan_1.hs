{-# htermination atan :: Float -> Float #-}
