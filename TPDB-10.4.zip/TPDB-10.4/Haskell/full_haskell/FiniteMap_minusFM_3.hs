{-# htermination minusFM :: FiniteMap Char b1 -> FiniteMap Char b2 -> FiniteMap Char b1 #-}
import FiniteMap
