{-# htermination fmToList_LE :: FiniteMap (Ratio Int) b -> (Ratio Int) ->  [((Ratio Int),b)] #-}
import FiniteMap
