{-# htermination max :: Ordering -> Ordering -> Ordering #-}
