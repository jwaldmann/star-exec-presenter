{-# htermination index :: ((),()) -> () -> Int #-}
