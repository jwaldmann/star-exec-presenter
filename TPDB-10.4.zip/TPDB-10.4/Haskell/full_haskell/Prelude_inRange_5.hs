{-# htermination inRange :: (Ordering,Ordering) -> Ordering -> Bool #-}
