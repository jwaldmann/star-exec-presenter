{-# htermination takeWhile :: (a -> Bool) -> [a] -> [a] #-}
