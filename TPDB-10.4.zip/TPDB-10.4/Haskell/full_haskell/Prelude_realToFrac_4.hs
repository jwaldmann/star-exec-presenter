{-# htermination realToFrac :: (Ratio Int) -> Float #-}
