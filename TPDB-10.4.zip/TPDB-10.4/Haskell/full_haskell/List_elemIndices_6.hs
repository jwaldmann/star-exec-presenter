{-# htermination elemIndices :: Bool -> [Bool] -> [Int] #-}
import List
