{-# htermination isPrefixOf :: [Char] -> [Char] -> Bool #-}
import List
