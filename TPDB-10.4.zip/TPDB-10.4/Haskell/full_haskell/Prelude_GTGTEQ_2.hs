{-# htermination (>>=) :: Maybe a -> (a -> Maybe b) -> Maybe b #-}
