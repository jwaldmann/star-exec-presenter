{-# htermination showsPrec :: (Show a, Show k) => Int -> (Either a k) -> String -> String #-}
