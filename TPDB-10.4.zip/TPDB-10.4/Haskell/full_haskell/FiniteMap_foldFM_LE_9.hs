{-# htermination foldFM_LE :: Ord a => ((Maybe a) -> b -> c -> c) -> c -> (Maybe a) -> FiniteMap (Maybe a) b -> c #-}
import FiniteMap
