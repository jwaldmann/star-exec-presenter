{-# htermination print :: Bool -> IO () #-}
