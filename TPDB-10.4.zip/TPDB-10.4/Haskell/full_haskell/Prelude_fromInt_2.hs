{-# htermination fromInt :: Int -> Int #-}
