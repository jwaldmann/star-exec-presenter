{-# htermination foldFM_LE :: (Bool -> b -> c -> c) -> c -> Bool -> FiniteMap Bool b -> c #-}
import FiniteMap
