{-# htermination foldFM_GE :: (Float -> b -> c -> c) -> c -> Float -> FiniteMap Float b -> c #-}
import FiniteMap
