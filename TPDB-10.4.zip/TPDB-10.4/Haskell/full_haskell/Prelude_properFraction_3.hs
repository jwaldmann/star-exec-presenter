{-# htermination properFraction :: (Ratio Int) -> (Int,(Ratio Int)) #-}
