{-# htermination blockIO :: ((a -> IOResult) -> IO ()) -> IO a #-}
