{-# htermination minimum :: (Ord a, Ord k) => [(a,k)] -> (a,k) #-}
