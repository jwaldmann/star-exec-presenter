{-# htermination fmToList_GE :: FiniteMap (Ratio Int) b -> (Ratio Int) ->  [((Ratio Int),b)] #-}
import FiniteMap
