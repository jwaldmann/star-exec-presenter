{-# htermination realToFrac :: Real a => a -> Float #-}
