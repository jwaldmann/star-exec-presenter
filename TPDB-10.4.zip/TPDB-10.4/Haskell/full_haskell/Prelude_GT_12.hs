{-# htermination (>) :: (Ord a, Ord k) => (a,k) -> (a,k) -> Bool #-}
