{-# htermination intersectFM_C :: Ord a => (b1 -> b2 -> b3) -> FiniteMap [a] b1 -> FiniteMap [a] b2 -> FiniteMap [a] b3 #-}
import FiniteMap
