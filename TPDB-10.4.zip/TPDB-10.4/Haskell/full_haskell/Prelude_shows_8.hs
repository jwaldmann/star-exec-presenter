{-# htermination shows :: Bool -> String -> String #-}
