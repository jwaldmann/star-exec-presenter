{-# htermination unitFM :: a -> b -> FiniteMap a b #-}
import FiniteMap
