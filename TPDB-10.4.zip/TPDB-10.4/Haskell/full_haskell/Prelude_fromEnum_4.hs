{-# htermination fromEnum :: Int -> Int #-}
