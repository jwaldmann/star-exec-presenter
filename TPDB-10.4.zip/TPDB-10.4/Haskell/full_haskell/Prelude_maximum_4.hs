{-# htermination maximum :: Ord a => [[a]] -> [a] #-}
