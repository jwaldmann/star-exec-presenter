{-# htermination replicateM_ :: Int -> Maybe a -> Maybe () #-}
import Monad
