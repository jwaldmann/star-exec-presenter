{-# htermination addListToFM_C :: (b -> b -> b) -> FiniteMap Int b -> [(Int,b)] -> FiniteMap Int b #-}
import FiniteMap
