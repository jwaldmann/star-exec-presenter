{-# htermination compare :: (Ord a, Ord k) => (a,k) -> (a,k) -> Ordering #-}
