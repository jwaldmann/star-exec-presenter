{-# htermination show :: Ordering -> String #-}
