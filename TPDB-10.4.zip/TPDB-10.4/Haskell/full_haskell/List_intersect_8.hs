{-# htermination intersect :: [Float] -> [Float] -> [Float] #-}
import List
