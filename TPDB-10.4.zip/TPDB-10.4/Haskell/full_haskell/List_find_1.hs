{-# htermination find :: (a -> Bool) -> [a] -> Maybe a #-}
import List
