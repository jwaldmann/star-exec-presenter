{-# htermination (<) :: Float -> Float -> Bool #-}
