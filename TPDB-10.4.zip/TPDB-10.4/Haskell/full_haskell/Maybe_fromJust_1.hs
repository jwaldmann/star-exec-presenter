{-# htermination fromJust :: Maybe a -> a #-}
import Maybe
