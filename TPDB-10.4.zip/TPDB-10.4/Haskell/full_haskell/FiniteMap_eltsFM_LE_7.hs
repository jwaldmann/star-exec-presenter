{-# htermination eltsFM_LE :: FiniteMap (Ratio Int) b -> (Ratio Int) -> [b] #-}
import FiniteMap
