{-# htermination filterFM :: (Ord a, Ord k) => ((a,k) -> b -> Bool) -> FiniteMap (a,k) b -> FiniteMap (a,k) b #-}
import FiniteMap
