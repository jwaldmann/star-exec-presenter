{-# htermination isNothing :: Maybe a -> Bool #-}
import Maybe
