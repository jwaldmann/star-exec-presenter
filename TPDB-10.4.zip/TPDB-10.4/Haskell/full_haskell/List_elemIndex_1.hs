{-# htermination elemIndex :: Eq a => a -> [a] -> Maybe Int #-}
import List
