{-# htermination addToFM :: Ord a => FiniteMap a b -> a -> b  -> FiniteMap a b #-}
import FiniteMap
