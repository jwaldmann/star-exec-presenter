{-# htermination minFM :: FiniteMap Ordering b -> Maybe Ordering #-}
import FiniteMap
