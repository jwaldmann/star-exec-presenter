{-# htermination truncate :: (Ratio Int) -> Int #-}
