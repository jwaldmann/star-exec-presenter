{-# htermination (>>) :: [] a -> [] b -> [] b #-}
