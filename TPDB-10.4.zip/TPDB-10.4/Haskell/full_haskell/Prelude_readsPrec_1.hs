{-# htermination readsPrec :: Read a => Int -> String -> [(a,String)] #-}
