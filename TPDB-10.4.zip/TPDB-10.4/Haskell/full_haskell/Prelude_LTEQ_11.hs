{-# htermination (<=) :: Ordering -> Ordering -> Bool #-}
