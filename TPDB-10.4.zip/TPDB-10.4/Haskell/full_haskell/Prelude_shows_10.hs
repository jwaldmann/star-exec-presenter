{-# htermination shows :: (Show a) => (Maybe a) -> String -> String #-}
