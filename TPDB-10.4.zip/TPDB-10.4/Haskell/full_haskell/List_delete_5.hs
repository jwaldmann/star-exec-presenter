{-# htermination delete :: Int -> [Int] -> [Int] #-}
import List
