{-# htermination elemFM :: Int -> FiniteMap Int b -> Bool #-}
import FiniteMap
