{-# htermination isPrefixOf :: [Ordering] -> [Ordering] -> Bool #-}
import List
