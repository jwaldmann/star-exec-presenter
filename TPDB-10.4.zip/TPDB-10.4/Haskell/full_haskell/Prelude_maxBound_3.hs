{-# htermination maxBound :: Char #-}
