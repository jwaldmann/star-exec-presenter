{-# htermination zipWithM_ :: (a -> b -> IO c) -> [a] -> [b] -> IO () #-}
import Monad
