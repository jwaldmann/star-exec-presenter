{-# htermination signum :: Float -> Float #-}
