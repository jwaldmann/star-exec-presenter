{-# htermination isLower :: Char -> Bool #-}
