{-# htermination listToFM :: [(Int,b)] -> FiniteMap Int b #-}
import FiniteMap
