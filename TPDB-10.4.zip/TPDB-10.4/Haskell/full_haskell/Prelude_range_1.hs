{-# htermination range :: Ix a => (a,a) -> [a] #-}
