{-# htermination foldFM_GE :: (Ord a, Ord k) => ((a,k) -> b -> c -> c) -> c -> (a,k) -> FiniteMap (a,k) b -> c #-}
import FiniteMap
