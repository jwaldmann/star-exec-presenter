{-# htermination toRational :: (Ratio Int) -> Rational #-}
