{-# htermination readIO :: String -> IO Char #-}
