{-# htermination replicateM :: Int -> [] a -> [] [a] #-}
import Monad
