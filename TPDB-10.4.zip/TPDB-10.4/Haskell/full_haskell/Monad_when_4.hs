{-# htermination when :: Bool -> IO () -> IO () #-}
import Monad
