{-# htermination eltsFM_LE :: FiniteMap Bool b -> Bool -> [b] #-}
import FiniteMap
