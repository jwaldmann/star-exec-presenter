{-# htermination recip :: Float -> Float #-}
