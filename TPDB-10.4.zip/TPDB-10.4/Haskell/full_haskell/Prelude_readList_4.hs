{-# htermination readList :: Read a => String -> [([[a]],String)] #-}
