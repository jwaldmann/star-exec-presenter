{-# htermination elemIndex :: Char -> [Char] -> Maybe Int #-}
import List
