{-# htermination read :: String -> Float #-}
