{-# htermination min :: (Ratio Int) -> (Ratio Int) -> (Ratio Int) #-}
