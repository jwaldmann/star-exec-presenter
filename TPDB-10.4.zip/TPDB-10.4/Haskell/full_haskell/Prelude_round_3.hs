{-# htermination round :: (Ratio Int) -> Int #-}
