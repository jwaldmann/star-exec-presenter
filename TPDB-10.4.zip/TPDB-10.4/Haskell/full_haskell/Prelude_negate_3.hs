{-# htermination negate :: Float -> Float #-}
