{-# htermination min :: Ordering -> Ordering -> Ordering #-}
