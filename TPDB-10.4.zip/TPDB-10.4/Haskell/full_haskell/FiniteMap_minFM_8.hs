{-# htermination minFM :: FiniteMap Bool b -> Maybe Bool #-}
import FiniteMap
