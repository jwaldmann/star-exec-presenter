{-# htermination liftM4 :: (a -> b -> c -> d -> e) -> ([] a -> [] b -> [] c -> [] d -> [] e) #-}
import Monad
