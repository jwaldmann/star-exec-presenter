{-# htermination enumFrom :: (Ratio Int) -> [(Ratio Int)] #-}
