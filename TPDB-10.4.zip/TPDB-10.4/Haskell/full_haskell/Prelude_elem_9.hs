{-# htermination elem :: (Ratio Int) -> [(Ratio Int)] -> Bool #-}
