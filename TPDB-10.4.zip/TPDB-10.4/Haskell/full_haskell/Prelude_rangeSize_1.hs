{-# htermination rangeSize :: Ix a => (a,a) -> Int #-}
