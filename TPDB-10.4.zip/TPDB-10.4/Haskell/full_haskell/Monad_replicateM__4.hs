{-# htermination replicateM_ :: Int -> IO a -> IO () #-}
import Monad
