{-# htermination isPrefixOf :: (Eq a, Eq k) => [(a, k)] -> [(a, k)] -> Bool #-}
import List
