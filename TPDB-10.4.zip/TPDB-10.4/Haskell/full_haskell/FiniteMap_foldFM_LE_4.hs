{-# htermination foldFM_LE :: Ord a => ([a] -> b -> c -> c) -> c -> [a] -> FiniteMap [a] b -> c #-}
import FiniteMap
