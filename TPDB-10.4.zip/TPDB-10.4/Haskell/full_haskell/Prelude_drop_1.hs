{-# htermination drop :: Int -> [a] -> [a] #-}
