{-# htermination approxRational :: RealFrac a => a -> a -> Rational #-}
