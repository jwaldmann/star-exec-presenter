{-# htermination eltsFM_GE :: FiniteMap Int b -> Int -> [b] #-}
import FiniteMap
