{-# htermination read :: String -> Bool #-}
