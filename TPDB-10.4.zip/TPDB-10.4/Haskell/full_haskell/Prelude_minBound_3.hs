{-# htermination minBound :: Char #-}
