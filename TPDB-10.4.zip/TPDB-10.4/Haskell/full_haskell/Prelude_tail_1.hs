{-# htermination tail :: [a] -> [a] #-}
