{-# htermination enumFromThen :: Float -> Float -> [Float] #-}
