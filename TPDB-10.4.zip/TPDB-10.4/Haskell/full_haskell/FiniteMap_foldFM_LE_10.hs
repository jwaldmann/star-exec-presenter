{-# htermination foldFM_LE :: (Ord a, Ord k) => ((Either a k) -> b -> c -> c) -> c -> (Either a k) -> FiniteMap (Either a k) b -> c #-}
import FiniteMap
