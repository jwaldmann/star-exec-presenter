{-# htermination (/=) :: Eq a => [a] -> [a] -> Bool #-}
