{-# htermination floor  :: RealFrac a => a -> Int #-}
