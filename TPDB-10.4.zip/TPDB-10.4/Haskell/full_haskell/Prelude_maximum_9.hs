{-# htermination maximum :: Ord a => [(Maybe a)] -> (Maybe a) #-}
