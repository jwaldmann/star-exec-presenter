{-# htermination (==) :: Int -> Int -> Bool #-}
