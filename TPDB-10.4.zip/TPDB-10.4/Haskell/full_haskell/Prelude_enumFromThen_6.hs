{-# htermination enumFromThen :: (Ratio Int) -> (Ratio Int) -> [(Ratio Int)] #-}
