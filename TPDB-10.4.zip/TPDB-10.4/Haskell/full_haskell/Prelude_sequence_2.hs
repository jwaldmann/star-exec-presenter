{-# htermination sequence :: [[] a] -> [] [a] #-}
