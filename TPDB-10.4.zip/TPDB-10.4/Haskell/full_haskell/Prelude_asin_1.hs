{-# htermination asin :: Float -> Float #-}
