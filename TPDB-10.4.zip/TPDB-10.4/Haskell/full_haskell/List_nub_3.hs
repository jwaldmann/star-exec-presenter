{-# htermination nub :: [Char] -> [Char] #-}
import List
