{-# htermination readParen :: Read a => Bool -> (String -> [(a,String)]) -> (String -> [(a,String)]) #-}
