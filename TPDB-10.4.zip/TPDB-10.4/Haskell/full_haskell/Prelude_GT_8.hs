{-# htermination (>) :: Bool -> Bool -> Bool #-}
