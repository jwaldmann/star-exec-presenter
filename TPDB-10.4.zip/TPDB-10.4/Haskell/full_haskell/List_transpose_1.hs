{-# htermination transpose :: [[a]] -> [[a]] #-}
import List
