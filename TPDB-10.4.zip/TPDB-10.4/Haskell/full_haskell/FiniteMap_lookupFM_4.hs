{-# htermination lookupFM :: Ord a => FiniteMap [a] b -> [a] -> Maybe b #-}
import FiniteMap
