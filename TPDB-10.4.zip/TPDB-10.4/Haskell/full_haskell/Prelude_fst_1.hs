{-# htermination fst :: (a,b) -> a #-}
