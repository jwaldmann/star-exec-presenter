{-# htermination minFM :: FiniteMap (Ratio Int) b -> Maybe (Ratio Int) #-}
import FiniteMap
