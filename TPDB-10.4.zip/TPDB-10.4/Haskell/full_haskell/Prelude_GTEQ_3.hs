{-# htermination (>=) :: Char -> Char -> Bool #-}
