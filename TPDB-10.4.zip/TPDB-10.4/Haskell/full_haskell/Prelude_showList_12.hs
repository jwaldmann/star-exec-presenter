{-# htermination showList :: [Ordering] -> String -> String #-}
