{-# htermination exponent :: Float -> Int #-}
