{-# htermination pred :: () -> () #-}
