{-# htermination addListToFM_C :: (b -> b -> b) -> FiniteMap Bool b -> [(Bool,b)] -> FiniteMap Bool b #-}
import FiniteMap
