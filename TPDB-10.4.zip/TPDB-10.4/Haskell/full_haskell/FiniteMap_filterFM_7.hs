{-# htermination filterFM :: ((Ratio Int) -> b -> Bool) -> FiniteMap (Ratio Int) b -> FiniteMap (Ratio Int) b #-}
import FiniteMap
