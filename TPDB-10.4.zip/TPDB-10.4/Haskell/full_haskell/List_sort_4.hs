{-# htermination sort :: Ord a => [[a]] -> [[a]] #-}
import List
