{-# htermination lookupWithDefaultFM :: Ord a => FiniteMap a b -> b -> a -> b #-}
import FiniteMap
