{-# htermination lookupWithDefaultFM :: FiniteMap Float b -> b -> Float -> b #-}
import FiniteMap
