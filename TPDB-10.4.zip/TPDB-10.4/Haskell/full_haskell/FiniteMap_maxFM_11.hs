{-# htermination maxFM :: FiniteMap Ordering b -> Maybe Ordering #-}
import FiniteMap
