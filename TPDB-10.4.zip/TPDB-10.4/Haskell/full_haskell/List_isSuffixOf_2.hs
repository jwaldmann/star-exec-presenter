{-# htermination isSuffixOf :: Eq a => [a] -> [a] -> Bool #-}
import List
