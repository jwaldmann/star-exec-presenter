{-# htermination zip3 :: [a] -> [b] -> [c] -> [(a,b,c)] #-}
