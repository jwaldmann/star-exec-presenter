{-# htermination keysFM_GE :: FiniteMap Bool b -> Bool -> [Bool] #-}
import FiniteMap
