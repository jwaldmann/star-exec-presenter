{-# htermination notElem :: Bool -> [Bool] -> Bool #-}
