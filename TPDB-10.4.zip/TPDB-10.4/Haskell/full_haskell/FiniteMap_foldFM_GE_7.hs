{-# htermination foldFM_GE :: ((Ratio Int) -> b -> c -> c) -> c -> (Ratio Int) -> FiniteMap (Ratio Int) b -> c #-}
import FiniteMap
