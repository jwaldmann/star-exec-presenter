{-# htermination readSigned :: Real a => (String -> [(a,String)]) -> (String -> [(a,String)]) #-}
