{-# htermination maximum :: (Ord a, Ord k) => [(Either a k)] -> (Either a k) #-}
