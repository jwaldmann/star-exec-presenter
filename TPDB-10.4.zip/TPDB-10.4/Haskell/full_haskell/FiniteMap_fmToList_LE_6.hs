{-# htermination fmToList_LE :: FiniteMap Float b -> Float ->  [(Float,b)] #-}
import FiniteMap
