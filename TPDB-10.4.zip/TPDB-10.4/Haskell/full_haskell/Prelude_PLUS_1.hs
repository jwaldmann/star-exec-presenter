{-# htermination (+) :: Num a => a -> a -> a #-}
