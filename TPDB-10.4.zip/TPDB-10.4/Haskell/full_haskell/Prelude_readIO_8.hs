{-# htermination readIO :: String -> IO Bool #-}
