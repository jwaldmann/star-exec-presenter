{-# htermination readLn :: IO Bool #-}
