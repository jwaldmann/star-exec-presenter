{-# htermination toEnum :: Int -> Char #-}
