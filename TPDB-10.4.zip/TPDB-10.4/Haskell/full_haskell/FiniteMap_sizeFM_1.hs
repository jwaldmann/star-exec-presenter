{-# htermination sizeFM :: FiniteMap a b -> Int #-}
import FiniteMap
