{-# htermination uncurry :: (a -> b -> c) -> ((a,b) -> c) #-}
