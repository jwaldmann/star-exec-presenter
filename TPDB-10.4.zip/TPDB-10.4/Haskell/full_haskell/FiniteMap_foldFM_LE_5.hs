{-# htermination foldFM_LE :: (Int -> b -> c -> c) -> c -> Int -> FiniteMap Int b -> c #-}
import FiniteMap
