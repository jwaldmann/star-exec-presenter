{-# htermination (/=) :: Bool -> Bool -> Bool #-}
