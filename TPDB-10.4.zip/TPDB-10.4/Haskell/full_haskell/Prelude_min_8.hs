{-# htermination min :: Bool -> Bool -> Bool #-}
