{-# htermination group :: Eq a => [[a]] -> [[[a]]] #-}
import List
