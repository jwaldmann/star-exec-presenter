{-# htermination concat :: [[a]] -> [a] #-}
