{-# htermination compare :: Ordering -> Ordering -> Ordering #-}
