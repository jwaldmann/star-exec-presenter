{-# htermination lookupWithDefaultFM :: (Ord a, Ord k) => FiniteMap (a,k) b -> b -> (a,k) -> b #-}
import FiniteMap
