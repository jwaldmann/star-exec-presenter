{-# htermination print :: Show a => [a] -> IO () #-}
