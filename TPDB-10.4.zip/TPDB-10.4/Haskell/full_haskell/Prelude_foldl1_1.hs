{-# htermination foldl1 :: (a -> a -> a) -> [a] -> a #-}
