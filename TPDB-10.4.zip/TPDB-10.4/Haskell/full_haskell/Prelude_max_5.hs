{-# htermination max :: Int -> Int -> Int #-}
