{-# htermination sortBy :: (a -> a -> Ordering) -> [a] -> [a] #-}
import List
