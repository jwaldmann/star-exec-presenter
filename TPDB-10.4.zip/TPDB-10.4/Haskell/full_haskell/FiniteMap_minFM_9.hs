{-# htermination minFM :: Ord a => FiniteMap (Maybe a) b -> Maybe (Maybe a) #-}
import FiniteMap
