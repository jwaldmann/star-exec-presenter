{-# htermination max :: Char -> Char -> Char #-}
