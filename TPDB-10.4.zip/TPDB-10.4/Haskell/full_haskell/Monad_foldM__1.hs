{-# htermination foldM_ :: Monad m => (a -> b -> m a) -> a -> [b] -> m () #-}
import Monad
