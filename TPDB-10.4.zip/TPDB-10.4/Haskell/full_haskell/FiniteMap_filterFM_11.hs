{-# htermination filterFM :: (Ordering -> b -> Bool) -> FiniteMap Ordering b -> FiniteMap Ordering b #-}
import FiniteMap
