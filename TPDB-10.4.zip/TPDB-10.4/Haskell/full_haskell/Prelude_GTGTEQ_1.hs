{-# htermination (>>=) :: [] a -> (a -> [] b) -> [] b #-}
