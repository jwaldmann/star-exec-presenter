{-# htermination inRange :: Ix a => (a,a) -> a -> Bool #-}
