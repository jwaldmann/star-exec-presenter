{-# htermination pred :: Enum a => a -> a #-}
