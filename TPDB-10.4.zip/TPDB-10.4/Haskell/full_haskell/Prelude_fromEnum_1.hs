{-# htermination fromEnum :: Enum a => a -> Int #-}
