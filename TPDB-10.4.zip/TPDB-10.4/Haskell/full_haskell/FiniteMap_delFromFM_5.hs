{-# htermination delFromFM :: FiniteMap Int b -> Int   -> FiniteMap Int b #-}
import FiniteMap
