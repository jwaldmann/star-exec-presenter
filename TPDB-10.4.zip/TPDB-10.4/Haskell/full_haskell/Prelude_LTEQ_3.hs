{-# htermination (<=) :: Char -> Char -> Bool #-}
