{-# htermination zip :: [a] -> [b] -> [(a,b)] #-}
