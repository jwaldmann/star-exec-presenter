{-# htermination intersect :: Eq a => [a] -> [a] -> [a] #-}
import List
