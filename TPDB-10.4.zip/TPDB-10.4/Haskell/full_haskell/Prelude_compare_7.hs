{-# htermination compare :: (Ratio Int) -> (Ratio Int) -> Ordering #-}
