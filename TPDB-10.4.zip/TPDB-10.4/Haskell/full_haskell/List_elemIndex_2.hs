{-# htermination elemIndex :: () -> [()] -> Maybe Int #-}
import List
