{-# htermination lookupFM :: FiniteMap Int b -> Int -> Maybe b #-}
import FiniteMap
