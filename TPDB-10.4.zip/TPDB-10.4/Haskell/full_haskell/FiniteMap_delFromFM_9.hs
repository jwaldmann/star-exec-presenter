{-# htermination delFromFM :: Ord a => FiniteMap (Maybe a) b -> (Maybe a)   -> FiniteMap (Maybe a) b #-}
import FiniteMap
