{-# htermination intToDigit :: Int -> Char #-}
