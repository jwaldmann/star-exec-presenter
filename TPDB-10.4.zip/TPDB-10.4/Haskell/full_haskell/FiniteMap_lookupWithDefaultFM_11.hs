{-# htermination lookupWithDefaultFM :: FiniteMap Ordering b -> b -> Ordering -> b #-}
import FiniteMap
