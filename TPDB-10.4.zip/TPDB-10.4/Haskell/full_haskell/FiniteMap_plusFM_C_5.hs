{-# htermination plusFM_C :: (b -> b -> b) -> FiniteMap Int b -> FiniteMap Int b -> FiniteMap Int b #-}
import FiniteMap
