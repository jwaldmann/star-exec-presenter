{-# htermination addToFM :: FiniteMap (Ratio Int) b -> (Ratio Int) -> b  -> FiniteMap (Ratio Int) b #-}
import FiniteMap
