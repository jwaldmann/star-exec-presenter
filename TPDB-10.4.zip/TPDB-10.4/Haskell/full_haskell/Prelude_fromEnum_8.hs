{-# htermination fromEnum :: Ordering -> Int #-}
