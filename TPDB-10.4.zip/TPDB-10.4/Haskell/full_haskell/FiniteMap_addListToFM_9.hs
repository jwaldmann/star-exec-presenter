{-# htermination addListToFM :: Ord a => FiniteMap (Maybe a) b -> [((Maybe a),b)] -> FiniteMap (Maybe a) b #-}
import FiniteMap
