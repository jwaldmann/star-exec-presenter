{-# htermination show :: (Show a, Show k) => (a,k) -> String #-}
