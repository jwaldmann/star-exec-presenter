{-# htermination unfoldr :: (b -> Maybe (a, b)) -> b -> [a] #-}
import List
