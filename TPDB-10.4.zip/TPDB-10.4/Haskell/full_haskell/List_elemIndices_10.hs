{-# htermination elemIndices :: Eq a => (Maybe a) -> [(Maybe a)] -> [Int] #-}
import List
