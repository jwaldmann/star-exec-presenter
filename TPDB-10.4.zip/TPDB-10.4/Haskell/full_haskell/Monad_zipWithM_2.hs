{-# htermination zipWithM :: (a -> b -> [] c) -> [a] -> [b] -> [] [c] #-}
import Monad
