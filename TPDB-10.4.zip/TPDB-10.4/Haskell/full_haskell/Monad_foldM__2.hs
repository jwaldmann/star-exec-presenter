{-# htermination foldM_ :: (a -> b -> [] a) -> a -> [b] -> [] () #-}
import Monad
