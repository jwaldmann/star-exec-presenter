{-# htermination getContents :: IO String #-}
