{-# htermination compare :: Bool -> Bool -> Ordering #-}
