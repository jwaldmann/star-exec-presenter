{-# htermination shows :: Char -> String -> String #-}
