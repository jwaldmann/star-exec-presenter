{-# htermination notElem :: Float -> [Float] -> Bool #-}
