{-# htermination succ :: () -> () #-}
