{-# htermination deleteFirstsBy :: (a -> a -> Bool) -> [a] -> [a] -> [a] #-}
import List
