{-# htermination notElem :: () -> [()] -> Bool #-}
