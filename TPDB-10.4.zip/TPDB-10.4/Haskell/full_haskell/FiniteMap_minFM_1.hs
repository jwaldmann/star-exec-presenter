{-# htermination minFM :: Ord a => FiniteMap a b -> Maybe a #-}
import FiniteMap
