{-# htermination signum :: Int -> Int #-}
