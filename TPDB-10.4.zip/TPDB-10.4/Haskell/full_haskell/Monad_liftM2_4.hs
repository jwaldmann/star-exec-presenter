{-# htermination liftM2 :: (a -> b -> c) -> (IO a -> IO b -> IO c) #-}
import Monad
