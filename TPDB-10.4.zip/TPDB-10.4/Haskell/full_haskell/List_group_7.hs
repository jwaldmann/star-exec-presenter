{-# htermination group :: [Ordering] -> [[Ordering]] #-}
import List
