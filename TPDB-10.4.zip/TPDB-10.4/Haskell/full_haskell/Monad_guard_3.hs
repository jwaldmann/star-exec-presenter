{-# htermination guard :: Bool -> Maybe () #-}
import Monad
