{-# htermination (==) :: Char -> Char -> Bool #-}
