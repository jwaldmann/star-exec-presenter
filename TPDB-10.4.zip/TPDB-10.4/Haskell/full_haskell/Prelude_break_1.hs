{-# htermination break :: (a -> Bool) -> [a] -> ([a],[a]) #-}
