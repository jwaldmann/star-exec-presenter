{-# htermination notElem :: Eq a => a -> [a] -> Bool #-}
