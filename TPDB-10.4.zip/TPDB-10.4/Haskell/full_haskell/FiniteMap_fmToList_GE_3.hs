{-# htermination fmToList_GE :: FiniteMap Char b -> Char ->  [(Char,b)] #-}
import FiniteMap
