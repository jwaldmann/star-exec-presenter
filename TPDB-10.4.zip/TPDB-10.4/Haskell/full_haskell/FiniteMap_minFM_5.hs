{-# htermination minFM :: FiniteMap Int b -> Maybe Int #-}
import FiniteMap
