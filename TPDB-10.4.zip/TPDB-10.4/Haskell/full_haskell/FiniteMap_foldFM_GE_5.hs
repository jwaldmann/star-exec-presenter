{-# htermination foldFM_GE :: (Int -> b -> c -> c) -> c -> Int -> FiniteMap Int b -> c #-}
import FiniteMap
