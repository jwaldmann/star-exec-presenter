{-# htermination minimumBy :: (a -> a -> Ordering) -> [a] -> a #-}
import List
