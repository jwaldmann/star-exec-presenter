{-# htermination delFromFM :: FiniteMap Bool b -> Bool   -> FiniteMap Bool b #-}
import FiniteMap
