{-# htermination minusFM :: FiniteMap Float b1 -> FiniteMap Float b2 -> FiniteMap Float b1 #-}
import FiniteMap
