{-# htermination readList :: String -> [([Float],String)] #-}
