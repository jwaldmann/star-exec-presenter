{-# htermination isSuffixOf :: [(Ratio Int)] -> [(Ratio Int)] -> Bool #-}
import List
