{-# htermination showChar :: Char -> String -> String #-}
