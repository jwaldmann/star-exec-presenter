{-# htermination group :: [Char] -> [[Char]] #-}
import List
