{-# htermination print :: (Show a, Show k) => (a,k) -> IO () #-}
