{-# htermination (^^) :: (Ratio Int) -> Int -> (Ratio Int) #-}
