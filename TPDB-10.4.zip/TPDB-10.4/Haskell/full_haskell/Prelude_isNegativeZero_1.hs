{-# htermination isNegativeZero :: Float -> Bool #-}
