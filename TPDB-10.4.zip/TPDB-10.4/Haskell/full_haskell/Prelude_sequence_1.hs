{-# htermination sequence :: Monad m => [m a] -> m [a] #-}
