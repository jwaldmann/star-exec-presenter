{-# htermination eltsFM_GE :: FiniteMap Bool b -> Bool -> [b] #-}
import FiniteMap
