{-# htermination genericIndex :: [b] -> Int -> b #-}
import List
