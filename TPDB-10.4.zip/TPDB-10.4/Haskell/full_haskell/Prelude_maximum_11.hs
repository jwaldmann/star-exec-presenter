{-# htermination maximum :: [Ordering] -> Ordering #-}
