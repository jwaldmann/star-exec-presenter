{-# htermination addListToFM :: FiniteMap Char b -> [(Char,b)] -> FiniteMap Char b #-}
import FiniteMap
