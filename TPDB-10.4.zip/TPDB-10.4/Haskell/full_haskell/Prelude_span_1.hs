{-# htermination span :: (a -> Bool) -> [a] -> ([a],[a]) #-}
