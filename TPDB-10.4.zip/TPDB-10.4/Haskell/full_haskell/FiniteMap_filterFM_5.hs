{-# htermination filterFM :: (Int -> b -> Bool) -> FiniteMap Int b -> FiniteMap Int b #-}
import FiniteMap
