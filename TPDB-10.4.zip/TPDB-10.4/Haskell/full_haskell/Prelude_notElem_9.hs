{-# htermination notElem :: (Ratio Int) -> [(Ratio Int)] -> Bool #-}
